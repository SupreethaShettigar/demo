package com.mphasis.dao;

import com.mphasis.pro.Product;
import com.mphasis.pro.Status;
import java.util.List;

public interface ProductDAO {

	Product insert(Product product);

	Product update(Product product);

	Status delete(Product product);

	List<Product> view();

	List<Product> search(String category );
}
